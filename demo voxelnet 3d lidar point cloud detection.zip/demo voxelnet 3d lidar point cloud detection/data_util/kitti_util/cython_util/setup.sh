ARCHFLAGS="-arch x86_64" CC=g++ CXX=g++ python setup.py build_ext --inplace
